hmc_update<-function(segment,fpca,control){
  p<-control$p
  J<-control$J
  beta<-segment$beta
  kinetic_current<-0
  kinetic_proposed<-0

  for(i in 1:p){
    index<-beta_indices(i,p,J)
    position<-beta[index]
    momentum<-rnorm(length(position))
    initial_momentum<-momentum
    step_size<-control$epsilon0*sqrt(J/length(position))
    n_steps<-ceiling(control$trajectory_length/step_size)

    gradient<-block_loggrad(position,i,fpca,segment$tau2,segment$vartheta,control)$gradient
    if(any(!is.finite(gradient))) return(list(success=FALSE))

    momentum<-momentum+0.5*step_size*gradient
    for(step in 1:n_steps){
      position<-position+step_size*momentum
      if (step < n_steps){
        gradient<-block_loggrad(position,i,fpca,segment$tau2,segment$vartheta,control)$gradient
        if(any(!is.finite(gradient))) return(list(success=FALSE))
        momentum<-momentum+step_size*gradient
      }
    }

    gradient<-block_loggrad(position,i,fpca,segment$tau2,segment$vartheta,control)$gradient
    if(any(!is.finite(gradient))) return(list(success=FALSE))
    momentum<-momentum+0.5*step_size*gradient

    beta[index]<-position
    kinetic_current<-kinetic_current+sum(initial_momentum^2)/2
    kinetic_proposed<-kinetic_proposed+sum(momentum^2)/2
  }

  list(success=TRUE,
       beta=beta,
       kinetic_current=kinetic_current,
       kinetic_proposed=kinetic_proposed)
}

truncated_inverse_gamma<-function(shape,rate,upper){
  lower_probability<-pgamma(1/upper,shape=shape,rate=rate)
  if(lower_probability >= 1) return(upper)

  probability<-runif(1,lower_probability,1)
  1/qgamma(probability,shape = shape,rate = rate)
}

gibbs_update<-function(segment,control){
  p<-control$p
  J<-control$J
  beta<-segment$beta
  tau2<-segment$tau2
  kappa<-cumprod(segment$vartheta)

  for(i in 1:p){
    beta_index<-beta_indices(i,p,J)
    tau_index<-tau_indices(i,p)
    coefficients<-split_beta(beta[beta_index],i,p,J)
    n_off<-p-i

    tau2[tau_index[1L]]<-truncated_inverse_gamma(shape=(J-3)/2,
                                                 rate=kappa[i]* sum((1:(J-1))^2 *coefficients$a[-1]^2)/2,
                                                 upper=control$c_tau2)
    if(n_off > 0){
      tau_b_index<-tau_index[2:(n_off+1)]
      tau_c_index<-tau_index[(n_off+2):(2*n_off+1)]
      for(r in 1:n_off){
        tau2[tau_b_index[r]]<-truncated_inverse_gamma(shape=(J-3)/2,
                                                      rate=kappa[i]*sum((1:(J-1))^2 *coefficients$b[-1,r]^2)/2,
                                                      upper=control$c_tau2)
        tau2[tau_c_index[r]]<-truncated_inverse_gamma(shape=(J-2)/2,
                                                      rate=kappa[i]*sum((1:J)^2*coefficients$c[,r]^2)/2,
                                                      upper = control$c_tau2)
      }
    }
  }

  vartheta<-segment$vartheta
  beta_dimensions<-J*(1+2*(p-1:p))
  base_quadratic<-numeric(p)
  for(i in 1:p){
    beta_index<-beta_indices(i,p,J)
    precision<-base_precision(i,tau2,p,J,control)
    base_quadratic[i]<-sum(precision*beta[beta_index]^2)
  }

  for(h in 1:p){
    affected_rows<-h:p
    kappa_without_h<-cumprod(vartheta)[affected_rows]/vartheta[h]
    prior_shape<-if(h == 1L) control$a1 else control$a2
    posterior_shape<-prior_shape+sum(beta_dimensions[affected_rows])/2
    posterior_rate<-1+sum(kappa_without_h*base_quadratic[affected_rows])/2
    vartheta[h] <- rgamma(1,shape=posterior_shape,rate=posterior_rate)
  }

  segment$tau2<-tau2
  segment$vartheta<-vartheta
  segment
}
