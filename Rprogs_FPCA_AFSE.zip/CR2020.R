#核函数
# 定义Bartlett核函数
K.BARTLETT=function(x) {
  value=ifelse(abs(x) <= 1, 1 - abs(x), 0)
  return(list(value=value,q=1,xi=1,int.k2=(2/3)))
}
#x=seq(-2,2,0.02)
#plot(x,K.BARTLETT(x)$value,type="l")



#定义Parzen核函数
K.PARZEN=function(x) {
  value=ifelse(abs(x)<=0.5,
               1-6*x^2+6*abs(x)^3,
               ifelse(abs(x)>0.5 & abs(x)<=1,2*(1-abs(x))^3,0)
  )
  return(list(value = value, q = 2, xi = 6, int.k2 = 0.5392857))
}
#x=seq(-2,2,0.02)
#plot(x,K.PARZEN(x)$value,type="l")


#计算核函数平方的积分值
# x2=function(x){K.PARZEN(x)$value^2}
# x2.int=integrate(x2,-1,1)
# x2.int


# Tukey_Hanning窗
K.TH=function(x){
  value=ifelse(abs(x)<=1,(1+cos(pi*x))/2,0)
  return(list(value=value,q=2,xi=(pi^2)/4,int.k2=3/4))
}
#x=seq(-2,2,0.02)
#plot(x,K.Tukey.Hanning(x)$value,type="l")


# Quadratic_spectral窗
K.QS=function(x){
  value=ifelse(x==0,1,
               ifelse(abs(x)<=1 & abs(x) >0,
                      (25/(12*(pi*x)^2))*(sin(6*pi*x/5)/(6*pi*x/5)-cos(6*pi*x/5)),0))
  return(list(value=value,q=2,xi=(18*pi^2)/125,int.k2=1))
}
#x=seq(-2,2,0.02)
#plot(x,K.QS(x)$value,type="l")




#定义Daniell核函数
K.DANIELL=function(x){
  # 当x不等于0时，返回sin(pi*x)/(pi*x)
  # 当x等于0时，返回1
  value=ifelse(x==0,1,
               ifelse(abs(x)<=1 & abs(x) >0,sin(pi*x)/(pi*x),0))
  return(list(value=value,q=2,xi=pi^2/4,int.k2=0.9028233))
}
#x=seq(-2,2,0.02)
#plot(x,K.DANIELL(x)$value,type="l")




KERNEL=function(h.lag,
                h=N^0.2,
                kernel.name="Bartlett"){
  
  if(kernel.name=="Bartlett"){
    #核函数
    kernel=K.BARTLETT(h.lag/h)
  }else if(kernel.name=="Parzen"){
    kernel=K.PARZEN(h.lag/h)
  }else if(kernel.name=="Daniell"){
    kernel=K.DANIELL(h.lag/h)
  }else if(kernel.name=="Tukey_Hanning"){
    kernel=K.TH(h.lag/h)
  }else if(kernel.name=="Quadratic_spectral"){
    kernel=K.QS(h.lag/h)
  }
  k=kernel$value
  p=kernel$q
  xi=kernel$xi
  int.k2=kernel$int.k2
  return(list(kernel.name=kernel.name,
              value=k,
              p=p,
              xi=xi,
              int.k2=int.k2))
}

#KERNEL(-20:20,kernel.name="Bartlett",h=N^0.2)



############################
## 1. kernel weights
############################
kweights <- function(x,
                     kernel = c("Truncated", "Bartlett", "Parzen",
                                "Tukey-Hanning", "Quadratic Spectral"),
                     normalize = FALSE) {
  kernel <- match.arg(kernel)
  x <- abs(x)
  
  if (normalize) {
    ca <- switch(kernel,
                 Truncated = 2,
                 Bartlett = 2/3,
                 Parzen = 0.539285,
                 "Tukey-Hanning" = 3/4,
                 "Quadratic Spectral" = 1)
  } else {
    ca <- 1
  }
  
  z <- ca * x
  
  out <- switch(kernel,
                Truncated = ifelse(z <= 1, 1, 0),
                
                Bartlett = ifelse(z <= 1, 1 - z, 0),
                
                Parzen = ifelse(z <= 1,
                                ifelse(z <= 0.5,
                                       1 - 6 * z^2 + 6 * z^3,
                                       2 * (1 - z)^3),
                                0),
                
                `Tukey-Hanning` = ifelse(z <= 1, (1 + cos(pi * z)) / 2, 0),
                
                `Quadratic Spectral` = {
                  y <- 6 * pi * z / 5
                  ifelse(z < 1e-8,
                         1,
                         3 * (sin(y) / y - cos(y)) / y^2)
                })
  
  return(out)
}







############################
## 3. spectral density estimation
############################
spectral_estimation <- function(data,
                                omega,
                                kern_type_ini = "BT",
                                kern_type = "BT",
                                omega_grid = NULL) {
  ## data: T x N matrix
  ## T = number of grid points
  ## N = sample size
  
  data <- as.matrix(data)
  T <- nrow(data)
  N <- ncol(data)
  
  ## center along time index
  data_center <- sweep(data, 1, rowMeans(data), "-")
  
  ## kernel code -> full name
  kern_name <- function(code) {
    switch(code,
           TR = "Truncated",
           BT = "Bartlett",
           PR = "Parzen",
           TH = "Tukey-Hanning",
           QS = "Quadratic Spectral",
           stop("Unknown kernel code. Use one of TR/BT/PR/TH/QS"))
  }
  
  kern_ini_name  <- kern_name(kern_type_ini)
  kern_main_name <- kern_name(kern_type)
  
  ## order q and xi
  q <- switch(kern_type,
              TR = 0,
              BT = 1,
              PR = 2,
              TH = 2,
              QS = 2,
              stop("Unknown kern_type"))
  
  xi <- switch(kern_type,
               TR = 1,
               BT = 1,
               PR = 6,
               TH = pi^2 / 4,
               QS = 18 * pi^2 / 125,
               stop("Unknown kern_type"))
  
  ## integral of k^2
  kernel_square_int <- switch(kern_type,
                              TR = 2,
                              BT = 2/3,
                              PR = 0.539285,
                              TH = 3/4,
                              QS = 1,
                              stop("Unknown kern_type"))
  
  ## omega grid for numerical integration
  if (is.null(omega_grid)) {
    omega_grid <- seq(-pi, pi, length.out = N)
  }
  
  ## sample autocovariance operator/matrix
  gamma_lag <- function(data, lag) {
    N <- ncol(data)
    if (lag < 0 || lag >= N) stop("lag must satisfy 0 <= lag < N")
    data[, (lag + 1):N, drop = FALSE] %*%
      t(data[, 1:(N - lag), drop = FALSE]) / N
  }
  
  ## precompute Gamma_h
  Gamma_list <- lapply(0:(N - 1), function(h) gamma_lag(data_center, h))
  
  ## F^{(r)}_{N,omega}
  F_omega_r <- function(omega, rorder, bandwidth, kernel_name_use) {
    out <- matrix(0 + 0i, nrow = T, ncol = T)
    
    ## h = 0: |h|^r 在 r > 0 时为零，仅零阶估计保留该项。
    if (rorder == 0) {
      out <- out + kweights(0 / bandwidth, kernel = kernel_name_use) * Gamma_list[[1]]
    }
    
    ## h >= 1
    for (h in 1:(N - 1)) {
      w_h <- kweights(h / bandwidth, kernel = kernel_name_use) * h^rorder
      if (abs(w_h) < 1e-14) next
      Gh <- Gamma_list[[h + 1]]
      out <- out +
        w_h * Gh * exp(-1i * h * omega) +
        w_h * Conj(t(Gh)) * exp( 1i * h * omega)
    }
    
    out / (2 * pi)
  }
  
  ## ||A||_{HS}^2
  hs_norm_sq <- function(A) {
    sum(Mod(A)^2)
  }
  
  ## (tr A)^2
  trace_sq <- function(A) {
    trA <- sum(diag(A))
    Re(trA)^2
  }
  
  ## trapezoidal rule
  int_on_omega <- function(vals, omega_grid) {
    sum((vals[-1] + vals[-length(vals)]) * diff(omega_grid) / 2)
  }
  
  ## plug-in bandwidth
  h_opt_fun <- function() {
    ## 不建议对 TR 用这套 plug-in
    if (q == 0) {
      p_opt <- floor(N^(1/3))
      p_opt <- max(1, min(N - 1, p_opt))
      return(p_opt)
    }
    
    p_ini_0 <- N^(1 / (2 * q + 1))
    p_ini_q <- 4 * N^(1 / (2 * q + 1))
    
    ## pilot estimators
    F0_list <- lapply(omega_grid, function(w) {
      F_omega_r(omega = w,
                rorder = 0,
                bandwidth = p_ini_0,
                kernel_name_use = kern_ini_name)
    })
    
    Fq_list <- lapply(omega_grid, function(w) {
      F_omega_r(omega = w,
                rorder = q,
                bandwidth = p_ini_q,
                kernel_name_use = kern_ini_name)
    })
    
    int_F0_norm <- int_on_omega(sapply(F0_list, hs_norm_sq), omega_grid)
    int_F0_tr   <- int_on_omega(sapply(F0_list, trace_sq), omega_grid)
    int_Fq_norm <- int_on_omega(sapply(Fq_list, hs_norm_sq), omega_grid)
    
    denom <- kernel_square_int * (int_F0_norm + int_F0_tr)
    
    if (denom <= 0) {
      p_opt <- floor(N^(1 / (2 * q + 1)))
      p_opt <- max(1, min(N - 1, p_opt))
      return(p_opt)
    }
    
    c_q_power <- (2 * q * xi^2 * int_Fq_norm) / denom
    c_q_hat   <- c_q_power^(1 / (2 * q + 1))
    p_opt     <- c_q_hat * N^(1 / (2 * q + 1))
    
    p_opt <- max(1, min(N - 1, Re(p_opt)))
    return(p_opt)
  }
  
  p_opt <- h_opt_fun()
  
  ## final estimator at one or more target frequencies
  omega <- as.numeric(omega)
  if (length(omega) < 1L || any(!is.finite(omega))) {
    stop("omega must contain at least one finite target frequency.")
  }

  F_omega_list <- lapply(omega, function(w) {
    F_omega_r(omega = w,
              rorder = 0,
              bandwidth = p_opt,
              kernel_name_use = kern_main_name)
  })
  F_omega <- if (length(F_omega_list) == 1L) {
    F_omega_list[[1L]]
  } else {
    simplify2array(F_omega_list)
  }
  
  return(list(
    p_opt = p_opt,
    F_omega = F_omega
  ))
}


# Rolling-window CR2020
# F 的维度为 T * T * time * omega
rolling_CR2020 <- function(
    X, block_size,
    omega = seq(0, 0.5, length.out = 51),
    thin_time = 10,
    omega_grid = NULL,
    kern_type_ini = "BT",
    kern_type = "BT") {
  X <- as.matrix(X)
  T <- nrow(X)
  N <- ncol(X)
  block_size <- as.integer(block_size)
  time <- seq(thin_time, N, by = thin_time)

  if (block_size > N) stop("block_size cannot exceed N.")

  bounds <- matrix(0, length(time), 2)
  colnames(bounds) <- c("left", "right")

  for (j in 1:length(time)) {
    left <- time[j] - floor(block_size / 2)
    left <- max(1, min(left, N - block_size + 1))
    right <- left + block_size - 1
    bounds[j, ] <- c(left, right)
  }

  F <- array(0 + 0i, c(T, T, length(time), length(omega)))
  bandwidth <- numeric(length(time))
  for (j in 1:length(time)) {
    X_window <- X[, bounds[j, 1]:bounds[j, 2], drop = FALSE]
    fit <- spectral_estimation(
      data = X_window,
      omega = 2 * pi * omega,
      omega_grid = omega_grid,
      kern_type_ini = kern_type_ini,
      kern_type = kern_type
    )

    F_window <- fit$F_omega
    if (length(omega) == 1) {
      F_window <- array(
        F_window,
        c(nrow(F_window), ncol(F_window), 1)
      )
    }

    F[, , j, ] <- F_window
    bandwidth[j] <- fit$p_opt
  }

  list(
    F = F,
    time = time,
    bandwidth = bandwidth
  )
}
