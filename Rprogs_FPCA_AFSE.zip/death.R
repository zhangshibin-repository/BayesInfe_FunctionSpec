death<-function(state,control){
  N<-control$N
  p<-control$p
  rejected<-state
  if(state$m==1L) return(rejected)
  # step 1: xi
  segment_id<-sample(1:(state$m-1),1)
  left <-state$segments[[segment_id]]
  right<-state$segments[[segment_id+1L]]
  left_boundary <-state$xi[segment_id]
  right_boundary<-state$xi[segment_id+2L]
  # step 2: tau and vartheta
  tau2_merged<-sqrt(left$tau2*right$tau2)
  vartheta_merged<-sqrt(left$vartheta*right$vartheta)
  u<-sqrt(left$tau2)/(sqrt(left$tau2)+sqrt(right$tau2))
  v<-sqrt(left$vartheta)/(sqrt(left$vartheta)+sqrt(right$vartheta))
  inside_u<-all(u>control$a_tau & u<1-control$a_tau)
  inside_v<-all(v>control$a_vartheta & v <1-control$a_vartheta)
  if(!inside_u || !inside_v) return(rejected)
  #
  merged_fpca<-segment_fpca(left_boundary,right_boundary,control)
  merged_laplace<-laplace_approximation(merged_fpca,tau2_merged,vartheta_merged,control,(left$beta+right$beta)/2)
  #
  left_laplace <-laplace_approximation(left$fpca, left$tau2, left$vartheta, control,left$beta)
  right_laplace<-laplace_approximation(right$fpca,right$tau2,right$vartheta,control,right$beta)
  if(is.null(merged_laplace) || is.null(left_laplace) || is.null(right_laplace)) return(rejected)
  merged_beta<-laplace_draw(merged_laplace)
  if(is.null(merged_beta)) return(rejected)
  
  merged<-list(beta=merged_beta,
               tau2=tau2_merged,
               vartheta=vartheta_merged,
               fpca=merged_fpca
               )

  proposed<-state
  proposed$m<-state$m-1L
  proposed$xi<-state$xi[-(segment_id+1L)]
  proposed$segments[[segment_id]]<-merged
  proposed$segments<-proposed$segments[-(segment_id+1L)]

  splittable_reverse<-which(diff(proposed$xi) >= 2L*control$t_min)
  split_support_size<-right_boundary-left_boundary- 2L*control$t_min+1L

  log_target_ratio<-segment_density(merged,control)-segment_density(left,control)-segment_density(right,control)+
    log_partition_prior(proposed$xi,N,control$t_min)-log_partition_prior(state$xi,N,control$t_min)

  current_splittable<-sum(diff(state$xi) >= 2*control$t_min)
  q_m_death<-if(state$m==control$M || current_splittable==0) 1 else 0.5
  q_m_birth<-if (proposed$m == 1) 1 else 0.5

  log_q_death<-log(q_m_death)-log(state$m-1L)+laplace_logdensity(merged$beta,merged_laplace)
  log_q_birth<-log(q_m_birth)-log(length(splittable_reverse))-log(split_support_size)-
    p^2*log(1-2*control$a_tau)-
    p*log(1-2*control$a_vartheta)+
    laplace_logdensity(left$beta, left_laplace)+
    laplace_logdensity(right$beta,right_laplace)

  samc_bias<-state$eta[state$m]-state$eta[state$m-1L]
  
  log_ratio<-log_target_ratio+samc_bias+log_q_birth-log_q_death-log_jacobian(tau2_merged,vartheta_merged,u,v)
  decision<-accept_move(log_ratio)

  if(decision$accepted) state<-proposed
  state
}
