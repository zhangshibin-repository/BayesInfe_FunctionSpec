# 算法2：选择 p，运行 B 次算法3, 计算重构均值
samc<-function(X,delta=0.05,fd_nbasis=21L,J=10L,M=8L,t_min=120L, 
              n_iter=10000L,burn_in=2000L,thin_sample=10L, 
              a_tau=0.3,a_vartheta=0.3,rho=0.8,relocation_radius=2L, 
              a1=1,a2=2,sigma_a=100,sigma_b=100,c_tau2=100, 
              epsilon0=0.02,trajectory_length=0.4, 
              T0=5,laplace_maxit=1000L,laplace_ridge=1e-12, 
              seed=20260910,thin_time=10,omega=seq(0,0.5,length.out=51)){
set.seed(seed)
X<-as.matrix(X)
T<-nrow(X)
N<-ncol(X)
B<-n_iter
n_save<-floor((B-burn_in)/thin_sample)
if(n_save<1) stop("No draws retained. Reduce burn_in or thin_sample.")
time<-seq(thin_time,N,by=thin_time)
basis<-create.bspline.basis(rangeval=c(0,1),nbasis=fd_nbasis,norder=4) # 这里只要定义一次就好,以后每次segment调用就好
# step 1: select p
p<-select_p(X,delta,basis)

control<-list(X=X,basis=basis,N=N,T=T,p=p,J=J,M=M,t_min=t_min,
              a_tau=a_tau,a_vartheta=a_vartheta,rho=rho,
              relocation_radius=relocation_radius,
              a1=a1,a2=a2,sigma_a=sigma_a,sigma_b=sigma_b,c_tau2=c_tau2,
              epsilon0=epsilon0,trajectory_length=trajectory_length,
              T0=T0,fd_nbasis=fd_nbasis,
              laplace_maxit=laplace_maxit,laplace_ridge=laplace_ridge
              )
  
# 初始化
fpca<-segment_fpca(0,N,control)
tau2<-rep(c_tau2/2,p^2)
vartheta<-rep(1,p)
laplace<-laplace_approximation(fpca,tau2,vartheta,control)
if(is.null(laplace)) stop("Initial Laplace approximation failed.")

state<-list(
  m=1,
  xi=c(0,N),
  eta=numeric(M),
  segments=list(
    list(beta=unlist(laplace$means,use.names=FALSE),tau2=tau2,vartheta=vartheta,fpca=fpca)
    )
)

draws<-vector("list",n_save)
  save_id<-0
  # 抽样：去掉 burn-in，每隔 thin_sample 次保存一次
  for(b in 1:B){
    state<-algorithm3(state,control,b)
    if(b>burn_in&&(b-burn_in)%%thin_sample==0){
      save_id<-save_id+1
      saved_segments<-vector("list",state$m)

      for(l in 1:state$m){
        segment<-state$segments[[l]]
        saved_segments[[l]]<-list(beta=segment$beta,
                                  tau2=segment$tau2,
                                  vartheta=segment$vartheta,
                                  eigenfunctions=segment$fpca$eigenfunctions
                                  )
      }

      draws[[save_id]]<-list(b=b,
                             m=state$m,
                             xi=state$xi,
                             segments=saved_segments
                             )
    }
    if(b%%100==0||b==B){cat("Iteration:", b, "/", B, "\n")}
  }

  # 每段只记录起点和终点的变化，最后沿时间累加
  kernel_change<-array(0+0i,c(T,T,length(time),length(omega)))
  for(s in 1:n_save){
    draw<-draws[[s]]
    for(l in 1:draw$m){
      time_id<-which(time>draw$xi[l]&time<=draw$xi[l+1])
      if(length(time_id)==0) next

      segment<-draw$segments[[l]]
      score<-score_spectrum(segment$beta,omega,p,J)
      eigenfunctions<-segment$eigenfunctions
      first<-time_id[1]
      last<-time_id[length(time_id)]

      for(g in 1:length(omega)){
        kernel<-eigenfunctions %*% score[, ,g] %*% t(eigenfunctions)
        kernel_change[, , first, g]<-kernel_change[, ,first,g]+kernel
        if(last<length(time)){
          kernel_change[, , last+1,g]<-kernel_change[, ,last+1,g]-kernel
        }
      }
    }
    if(s %% 100 == 0 || s==n_save){
      cat("Reconstruction:", s, "/", n_save, "\n")
    }
  }

  if(length(time)>1){
    for(g in 1:length(omega)){
      for (j in 2:length(time)){
        kernel_change[, ,j,g]<-kernel_change[, ,j-1,g]+kernel_change[, ,j,g]
      }
    }
  }

  kernel_sum<-kernel_change
  kernel_mean<-kernel_sum/n_save

  list(p=p,J=J,N=N,T=T,
       time=time,omega=omega,draws=draws,
       kernel_mean=kernel_mean
  )
}

score_spectrum<-function(beta,omega,p,J){
  psi<-psi_basis(omega,J)
  phi<-phi_basis(omega,J)
  spectra<-array(0+0i,dim=c(p,p,length(omega)))
  
  for(g in 1:length(omega)){
    cholesky_factor<-diag(1+0i,p)
    log_diagonal<-numeric(p)

    for(i in 1:p){
      beta_index<-beta_indices(i,p,J)
      coefficients<-split_beta(beta[beta_index],i,p,J)
      log_diagonal[i]<-sum(psi[g, ]*coefficients$a)

      n_off<-p-i
      if(n_off>0){
        for(r in 1:n_off){
          j<-i+r
          real_part<-sum(psi[g, ]*coefficients$b[,r])
          imaginary_part<-sum(phi[g, ]*coefficients$c[,r])
          cholesky_factor[i,j]<-real_part+1i*imaginary_part
        }
      }
    }

    inverse_diagonal<-diag(exp(-log_diagonal),p)
    precision<-Conj(t(cholesky_factor)) %*% inverse_diagonal %*% cholesky_factor
    spectrum<-solve(precision)
    spectra[, ,g]<-(spectrum+Conj(t(spectrum)))/2
  }
  spectra
}
