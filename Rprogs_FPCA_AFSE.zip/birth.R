birth<-function(state,control){
  N<-control$N
  p<-control$p
  rejected<-state
  # step 1: xi
  splittable<-which(diff(state$xi)>=2*control$t_min)
  if(length(splittable)==0) return(rejected)
  segment_id<-splittable[sample(length(splittable),1)]
  left_boundary<-state$xi[segment_id]
  right_boundary<-state$xi[segment_id+1]
  split_support<-(left_boundary+control$t_min):(right_boundary-control$t_min)
  split_point<-split_support[sample(length(split_support),1)]
  current<-state$segments[[segment_id]]
  # step 2: tau and vartheta
  u<-runif(p^2,control$a_tau,1-control$a_tau)
  v<-runif(p,control$a_vartheta,1-control$a_vartheta)
  tau2_left<-current$tau2*u/(1-u)
  tau2_right<-current$tau2*(1-u)/u
  vartheta_left<-current$vartheta*v/(1-v)
  vartheta_right<-current$vartheta*(1-v)/v
  # step 3: beta
  left_fpca <-segment_fpca(left_boundary,split_point,control)
  right_fpca<-segment_fpca(split_point,right_boundary,control)
  left_laplace  <- laplace_approximation(left_fpca,tau2_left,vartheta_left,control,current$beta)
  right_laplace <- laplace_approximation(right_fpca,tau2_right,vartheta_right,control,current$beta)
  #
  current_laplace<-laplace_approximation(current$fpca,current$tau2,current$vartheta,control,current$beta)
  if(is.null(left_laplace) || is.null(right_laplace) || is.null(current_laplace)) return(rejected)

  left_beta  <- laplace_draw(left_laplace)
  right_beta <- laplace_draw(right_laplace)
  if (is.null(left_beta) || is.null(right_beta)) return(rejected)

  left<- list(beta=left_beta, tau2=tau2_left, vartheta=vartheta_left, fpca=left_fpca)
  right<-list(beta=right_beta,tau2=tau2_right,vartheta=vartheta_right,fpca=right_fpca)

  proposed<-state
  proposed$m<-state$m+1L
  proposed$xi<-c(state$xi[1:segment_id],split_point,state$xi[(segment_id+1):(state$m+1)])
  proposed$segments[[segment_id]]<-left
  proposed$segments<-append(proposed$segments,list(right),after=segment_id)

  log_target_ratio<- 
    segment_density(left,control)+segment_density(right,control)-segment_density(current,control)+
    log_partition_prior(proposed$xi,N,control$t_min)-log_partition_prior(state$xi,N,control$t_min)

  q_m_birth<-if(state$m==1) 1 else 0.5
  proposed_splittable<-sum(diff(proposed$xi)>=2*control$t_min)
  q_m_death<-if(proposed$m==control$M || proposed_splittable==0) 1 else 0.5

  log_q_forward<-
    log(q_m_birth)-log(length(splittable))-
    log(length(split_support))-
    p^2*log(1-2*control$a_tau)-
    p*log(1-2*control$a_vartheta)+
    laplace_logdensity(left$beta,left_laplace) +
    laplace_logdensity(right$beta,right_laplace)

  log_q_reverse<-log(q_m_death)-log(proposed$m-1L)+laplace_logdensity(current$beta, current_laplace)
  
  samc_bias<-state$eta[state$m]-state$eta[state$m+1L]
  
  log_ratio<-log_target_ratio+samc_bias+log_q_reverse-log_q_forward+log_jacobian(current$tau2,current$vartheta,u,v)
  decision<-accept_move(log_ratio)

  if(decision$accepted) state<-proposed
  state
}
