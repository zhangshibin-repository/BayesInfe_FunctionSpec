# output: K * J
psi_basis<-function(omega,J){cbind(1,sqrt(2)*cos(2*pi*outer(omega,1:(J-1))))}
phi_basis<-function(omega,J){sqrt(2)*sin(2*pi*outer(omega,1:J))}

# 第 i 个参数块在 beta 中的位置
beta_indices<-function(i,p,J){
  block_size<-J*(1+2*(p-1:p))
  i_last<-cumsum(block_size)[i]
  i_first<-i_last-block_size[i]+1
  i_first:i_last
}

# 第 i 个参数块在 tau2 中的位置
tau_indices<-function(i,p){
  block_size<-1+2*(p-1:p)
  i_last<-cumsum(block_size)[i]
  i_first<-i_last-block_size[i]+1
  i_first:i_last
}

# 参数拆分
split_beta<-function(beta_i,i,p,J){
  n_off<-p-i
  a<-beta_i[1:J]
  if(n_off==0) return(list(a=a,b=NULL,c=NULL))
  n_beta<-J*n_off
  b<-matrix(beta_i[(J+1):(J+n_beta)],J,n_off)
  c<-matrix(beta_i[(J+n_beta+1):(J+2*n_beta)],J,n_off)
  list(a=a,b=b,c=c)
}

# j²/tau² 先验精度
base_precision<-function(i,tau2,p,J,control){
  tau_i<-tau2[tau_indices(i,p)]
  n_off<-p-i
  precision_a<-c(1/control$sigma_a^2,(1:(J-1))^2/tau_i[1])
  if(n_off==0) return(precision_a)

  tau_b<-tau_i[2:(n_off+1)]
  tau_c<-tau_i[(n_off+2):(2*n_off+1)]
  precision_b<-precision_c<-numeric(J*n_off)

  for(r in 1:n_off){
    index<-((r-1)*J+1):(r*J)
    precision_b[index]<-c(1/control$sigma_b^2,(1:(J-1))^2/tau_b[r])
    precision_c[index]<-(1:J)^2/tau_c[r]
  }
  c(precision_a,precision_b,precision_c)
}

log_jacobian<-function(tau2,vartheta,u,v){
  log_J_tau<-sum(log(2*tau2)-log(u)-log(1-u))
  log_J_vartheta<-sum(log(2*vartheta)-log(v)-log(1-v))
  log_J_tau+log_J_vartheta
}

accept_move<-function(log_ratio){
  accepted<-log(runif(1))<min(0,log_ratio)
  list(accepted=accepted)
}

log_partition_prior<-function(xi,N,t_min){
  m<-length(xi)-1
  #if (xi[1] != 0 || xi[m + 1] != N || any(diff(xi) < t_min)) return(-Inf)
  if(m==1) return(0)
  log_prob<-0
  for(l in 1:(m - 1)){log_prob<-log_prob-log(N-xi[l]-(m-l+1)*t_min+1)}
  log_prob
}

# 第 i 个 Cholesky 行的对数后验及梯度
block_loggrad<-function(beta_i,i,fpca,tau2,vartheta,control){
  p<-control$p
  J<-control$J
  coef<-split_beta(beta_i,i,p,J)
  eta<-as.vector(fpca$psi %*% coef$a)
  residual<-fpca$y[,i]
  n_off<-p-i

  if(n_off>0){
    y_rest<-fpca$y[,(i+1):p,drop=FALSE]
    transfer<-fpca$psi %*% coef$b+1i*fpca$phi %*% coef$c
    residual<-residual+rowSums(transfer*y_rest)
  }

  weighted<-abs(residual)^2*exp(-eta)
  if(any(!is.finite(weighted))){
    return(list(value=-Inf,gradient=rep(NA,length(beta_i))))
  }

  kappa_i<-prod(vartheta[1:i])
  precision<-kappa_i*base_precision(i,tau2,p,J,control)
  gradient<--precision*beta_i
  gradient[1:J]<-gradient[1:J]+crossprod(fpca$psi,weighted-1)

  if(n_off > 0){
    real_part<-Re(Conj(residual)*y_rest)
    imag_part<-Re(1i*Conj(residual)*y_rest)
    gradient_b<--2*crossprod(fpca$psi,exp(-eta)*real_part)
    gradient_c<--2*crossprod(fpca$phi,exp(-eta)*imag_part)

    n_beta<-J*n_off
    b_index<-(J+1):(J+n_beta)
    c_index<-(J+n_beta+1):(J+2*n_beta)
    gradient[b_index]<-gradient[b_index]+as.vector(gradient_b)
    gradient[c_index]<-gradient[c_index]+as.vector(gradient_c)
  }
  value<--sum(eta+weighted)-0.5*sum(precision*beta_i^2)
  list(value=value,gradient=as.vector(gradient))
}

# 第 i 个 Cholesky 行的解析 Hessian
block_hessian<-function(beta_i,i,fpca,tau2,vartheta,control){
  p<-control$p
  J<-control$J
  coef<-split_beta(beta_i,i,p,J)
  eta<-as.vector(fpca$psi %*% coef$a)
  residual<-fpca$y[,i]
  n_off<-p-i

  if(n_off > 0){
    y_rest<-fpca$y[,(i+1):p,drop=FALSE]
    transfer<-fpca$psi %*% coef$b+1i*fpca$phi%*%coef$c
    residual<-residual+rowSums(transfer*y_rest)
  }

  exp_eta<-exp(-eta)
  weighted<-abs(residual)^2*exp_eta
  if(any(!is.finite(weighted))) return(NULL)

  kappa_i<-prod(vartheta[1:i])
  precision<-kappa_i*base_precision(i,tau2,p,J,control)
  H<-matrix(0,length(beta_i),length(beta_i))
  a_index<-1:J
  H[a_index,a_index] <--crossprod(fpca$psi,weighted*fpca$psi)-diag(precision[a_index],J)
  if(n_off==0) return(H)

  n_beta<-J*n_off
  b_start<-J
  c_start<-J+n_beta

  for(r in 1:n_off){
    b_index<-b_start+((r-1)*J+1):(r*J)
    c_index<-c_start+((r-1)*J+1):(r*J)
    real_part<-Re(Conj(residual)*y_rest[,r])
    imag_part<-Re(1i*Conj(residual)*y_rest[,r])

    H_ab<-2*crossprod(fpca$psi,exp_eta*real_part*fpca$psi)
    H_ac<-2*crossprod(fpca$psi,exp_eta*imag_part*fpca$phi)

    H[a_index,b_index]<-H_ab
    H[b_index,a_index]<-t(H_ab)
    H[a_index,c_index]<-H_ac
    H[c_index,a_index]<-t(H_ac)
  }

  for(r in 1:n_off){
    b_r<-b_start+((r-1)*J+1):(r*J)
    c_r<-c_start+((r-1)*J+1):(r*J)

    for(s in 1:n_off){
      b_s<-b_start+((s-1)*J+1):(s*J)
      c_s<-c_start+((s-1)*J+1):(s*J)
      real_part<-Re(Conj(y_rest[,s])*y_rest[,r])
      imag_part<-Im(Conj(y_rest[,s])*y_rest[,r])

      H[b_r,b_s]<--2*crossprod(fpca$psi,exp_eta*real_part*fpca$psi)
      H[c_r,c_s]<--2*crossprod(fpca$phi,exp_eta*real_part*fpca$phi)
      H[b_r,c_s]<--2*crossprod(fpca$psi,exp_eta*imag_part*fpca$phi)
      H[c_s,b_r]<-t(H[b_r,c_s])

      if(r==s){
        H[b_r,b_s]<-H[b_r,b_s]-diag(precision[b_r],J)
        H[c_r,c_s]<-H[c_r,c_s]-diag(precision[c_r],J)
      }
    }
  }
  (H+t(H))/2
}

segment_beta_logposterior<-function(segment,control){
  p<-control$p
  J<-control$J
  value<-0
  for(i in 1:p){
    index<-beta_indices(i,p,J)
    value<-value+block_loggrad(segment$beta[index],i,segment$fpca,segment$tau2,segment$vartheta,control)$value
  }
  value
}

segment_density<-function(segment,control){
  p<-control$p
  J<-control$J
  if(any(segment$tau2<=0 | segment$tau2>control$c_tau2)) return(-Inf)
  if(any(segment$vartheta<=0)) return(-Inf)

  value<-0
  for(i in 1:p){
    index<-beta_indices(i,p,J)
    beta_i<-segment$beta[index]
    kappa_i<-prod(segment$vartheta[1:i])
    precision<-kappa_i*base_precision(i,segment$tau2,p,J,control)
    block<-block_loggrad(beta_i,i,segment$fpca,segment$tau2,segment$vartheta,control)
    value<-value+block$value+0.5*sum(log(precision))-0.5*length(beta_i)*log(2*pi)
  }

  shape<-c(control$a1,rep(control$a2,p-1))
  vartheta_prior<-sum(dgamma(segment$vartheta,shape,1,log=TRUE))
  value-p^2*log(control$c_tau2)+vartheta_prior
}

laplace_approximation<-function(fpca,tau2,vartheta,control,initial=NULL){
  p<-control$p
  J<-control$J
  if(is.null(initial)) initial<-numeric(J*p^2)
  means<-covariances<-vector("list",p)

  for(i in 1:p){
    index<-beta_indices(i,p,J)
    fn<-function(x){-block_loggrad(x,i,fpca,tau2,vartheta,control)$value}
    gr<-function(x){-block_loggrad(x,i,fpca,tau2,vartheta,control)$gradient}

    fit<-optim(
      initial[index],
      fn,gr,method="L-BFGS-B",
      control=list(
        maxit=control$laplace_maxit,
        factr=1e9,
        pgtol=1e-5
      )
    )
    if(fit$convergence != 0 || !is.finite(fit$value)) return(NULL)

    H<-block_hessian(fit$par,i,fpca,tau2,vartheta,control)
    if(is.null(H)) return(NULL)
    H<--(H + t(H))/2+diag(control$laplace_ridge,length(index))
    if (any(!is.finite(H))) return(NULL)
    E<-eigen(H,symmetric=TRUE)
    if(any(E$values<=0)) return(NULL)

    means[[i]]<-fit$par
    covariances[[i]]<-E$vectors%*%diag(1/E$values)%*%t(E$vectors)
  }
  list(means=means, covariances=covariances)
}

laplace_draw<-function(laplace){
  p<-length(laplace$means)
  beta_blocks<-vector("list",p)
  for(i in 1:p){
    mean_i<-laplace$means[[i]]
    covariance_i<-laplace$covariances[[i]]
    covariance_i<-(covariance_i+t(covariance_i))/2
    if(any(!is.finite(covariance_i))) return(NULL)

    E<-eigen(covariance_i,symmetric=TRUE)
    if(any(E$values<=0)) return(NULL)
    beta_blocks[[i]]<-as.numeric(mean_i+E$vectors%*%(sqrt(E$values)*rnorm(length(mean_i))))
  }
  unlist(beta_blocks,use.names=FALSE)
}

laplace_logdensity<-function(beta,laplace){
  p<-length(laplace$means)
  J<-length(laplace$means[[p]])
  value<-0
  for(i in 1:p){
    index<-beta_indices(i,p,J)
    mean_i<-laplace$means[[i]]
    covariance_i<-laplace$covariances[[i]]
    covariance_i<-(covariance_i+t(covariance_i))/2
    if (any(!is.finite(covariance_i))) return(-Inf)

    density_i<-mvtnorm::dmvnorm(
      beta[index],
      mean=mean_i,
      sigma=covariance_i,
      log=TRUE
    )
    if(!is.finite(density_i)) return(-Inf)
    value<-value+density_i
  }
  value
}
