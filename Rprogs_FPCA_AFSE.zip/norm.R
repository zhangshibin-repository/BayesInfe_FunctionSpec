# estimated, truth: T * T * time * omega
# Hilbert--Schmidt IMSE
imse_hs<-function(estimated,truth,u){
  du<-1/length(u)
  n_time<-dim(estimated)[3]
  n_omega<-dim(estimated)[4]
  total<-0
  for(j in 1:n_time){
    for(g in 1:n_omega){
      error<-estimated[, ,j,g]-truth[, ,j,g]
      total<-total+sqrt(sum(Mod(error)^2)*du^2)
    }
  }
  total/(n_time*n_omega)
}
# Nuclear IMSE
imse_nuclear<-function(estimated,truth,u){
  du<-1/length(u)
  n_time<-dim(estimated)[3]
  n_omega<-dim(estimated)[4]
  total<-0
  for(j in 1:n_time){
    for(g in 1:n_omega){
      A<-estimated[, ,j,g]-truth[, ,j,g]
      A<-(A+Conj(t(A)))/2
      eigenvalues<-eigen(A*du,symmetric=TRUE,only.values=TRUE)$values
      total <- total + sum(abs(Re(eigenvalues)))
    }
  }
  total/(n_time*n_omega)
}