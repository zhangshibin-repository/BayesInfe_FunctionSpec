# 算法3：一次 between-model → SAMC 权重更新 → within-model
algorithm3<-function(state,control,b){
  splittable<-sum(diff(state$xi)>=2*control$t_min)
  if(state$m==1){
    move<-"birth"
  } else if(state$m==control$M || splittable==0){
    move<-"death"
  }else{
    move<-if(runif(1)<0.5) "birth" else "death"
  }

  if(control$M>1){
    if(move=="birth"){
      state<-birth(state,control)
    }else{
      state<-death(state,control)
    }
  }

  indicator<-numeric(control$M)
  indicator[state$m]<-1
  step_size<-control$T0/max(control$T0,b)
  state$eta<-state$eta+step_size*(indicator-1/control$M)

  within(state,control)
}
