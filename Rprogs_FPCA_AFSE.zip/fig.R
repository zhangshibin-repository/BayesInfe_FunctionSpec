# 真实谱密度的四个时频切片
true_slices<-function(spectrum,
                      point_diag=c(0.3,0.7),
                      point_cross=c(0.3,0.7),time=NULL){
  u<-spectrum$u
  xi<-spectrum$xi
  n_omega<-length(spectrum$omega)
  if(is.null(time)){
    time<-if(!is.null(xi)) seq_len(tail(xi,1)) else spectrum$time
  }
  if(length(time)==0L || any(!is.finite(time))) stop("time must contain finite observation times.")

  # abrupt 的第三维是分段；smooth、stationary 的第三维是观测时间。
  if(!is.null(xi)){
    slice_id<-findInterval(time,xi,left.open=TRUE)
    if(any(slice_id<1L | slice_id>=length(xi))) stop("time is outside the partition boundaries.")
  } else {
    slice_id<-match(time,spectrum$time)
    if(anyNA(slice_id)) stop("time must be present in spectrum$time.")
  }

  diag_index<- c(which.min(abs(u-point_diag[1])), which.min(abs(u-point_diag[2])))
  cross_index<-c(which.min(abs(u-point_cross[1])),which.min(abs(u-point_cross[2])))

  slice<-function(i,j){
    t(matrix(spectrum$kernel[i,j,slice_id, ,drop=FALSE],
             nrow=length(time),ncol=n_omega))
  }
  values<-list(
    log(pmax(Re(slice(diag_index[1],diag_index[1])),1e-12)),
    log(pmax(Re(slice(diag_index[2],diag_index[2])),1e-12)),
    Re(slice(cross_index[1],cross_index[2])),
    Im(slice(cross_index[1],cross_index[2]))
  )
  values
}

# 后验均值谱密度的四个时频切片
estimated_slices<-function(fit,omega=fit$omega,
                           point_diag =c(0.3,0.7),
                           point_cross=c(0.3,0.7),time=seq_len(fit$N)){
  T<-fit$T
  n_time<-length(time)
  if(n_time==0L || any(!is.finite(time)) || any(time<1 | time>fit$N)){
    stop("time must be within 1:fit$N.")
  }
  u<-seq(0,1,length.out=T)
  n_omega<-length(omega)
  diag_index <-c(which.min(abs(u-point_diag[1])), which.min(abs(u-point_diag[2])))
  cross_index<-c(which.min(abs(u-point_cross[1])),which.min(abs(u-point_cross[2])))

  values<-list(matrix(0,n_omega,n_time),
               matrix(0,n_omega,n_time),
               matrix(0,n_omega,n_time),
               matrix(0,n_omega,n_time))

  for(s in 1:length(fit$draws)){
    draw<-fit$draws[[s]]
    for(l in 1:draw$m){
      time_id<-which(time>draw$xi[l] & time<=draw$xi[l+1])
      if(length(time_id)==0L) next
      segment<-draw$segments[[l]]
      f<-score_spectrum(segment$beta,omega,fit$p,fit$J)
      eigenfunctions<-segment$eigenfunctions

      nu_1<-eigenfunctions[diag_index[1], ,drop = FALSE]
      nu_2<-eigenfunctions[diag_index[2], ,drop = FALSE]
      nu_3<-eigenfunctions[cross_index[1], ,drop = FALSE]
      nu_4<-eigenfunctions[cross_index[2], ,drop = FALSE]

      segment_values<-matrix(0,4,n_omega)
      for(g in 1:n_omega){
        segment_values[1,g]<-Re(nu_1 %*% f[, ,g] %*% t(nu_1))
        segment_values[2,g]<-Re(nu_2 %*% f[, ,g] %*% t(nu_2))
        segment_values[3,g]<-Re(nu_3 %*% f[, ,g] %*% t(nu_4))
        segment_values[4,g]<-Im(nu_3 %*% f[, ,g] %*% t(nu_4))
      }

      for(r in 1:4) {values[[r]][,time_id]<-values[[r]][,time_id]+segment_values[r, ]}
    }
  }
  n_draws<-length(fit$draws)
  for(r in 1:4) values[[r]]<-values[[r]]/n_draws

  values[[1]]<-log(pmax(values[[1]],1e-12))
  values[[2]]<-log(pmax(values[[2]],1e-12))
  values
}


plot_slices<-function(true_values,estimated_values,omega,file,true_xi,
                      point_diag =c(0.3,0.7),
                      point_cross=c(0.3,0.7),
                      time=seq_len(ncol(true_values[[1]]))){
  expected_dim<-c(length(omega),length(time))
  if(length(true_values)!=4L || length(estimated_values)!=4L ||
     any(vapply(c(true_values,estimated_values),
                function(x) !identical(dim(x),expected_dim),logical(1)))){
    stop("Each slice must have length(omega) rows and length(time) columns.")
  }
  if(length(time)==0L || any(!is.finite(time)) || is.unsorted(time,strictly=TRUE)){
    stop("time must be finite and strictly increasing.")
  }
  titles<-c(
    paste0("log f(", point_diag[1], ", ", point_diag[1], ")"),
    paste0("log f(", point_diag[2], ", ", point_diag[2], ")"),
    paste0("Re f(", point_cross[1], ", ", point_cross[2], ")"),
    paste0("Im f(", point_cross[1], ", ", point_cross[2], ")")
  )
  colors<-colorRampPalette(c("#253494", "#2c7fb8", "#ffffbf", "#fdae61", "#a50026"))(160)
  pdf(file,width=12,height = 14)
  on.exit(dev.off(),add=TRUE)
  #layout(matrix(1:12,4,3,byrow=TRUE),widths=c(1,1,0.08))
  layout(matrix(1:12,4,3, byrow=TRUE),widths=c(1,1,0.15))
  par(
    cex.main = 1.6,  # 标题：True/Estimated log f、Re f、Im f
    cex.lab  = 1.4,  # 横纵轴名称：Time、Frequency
    cex.axis = 1.2   # 坐标轴刻度数字
  )
  for(r in 1:4){
    zlim<-range(c(true_values[[r]],estimated_values[[r]]))
    if(zlim[1]==zlim[2]) zlim<-zlim+c(-1,1)*1e-8

    par(mar=c(4,4,3,1))
    image(x=time,y=omega,z=t(true_values[[r]]),
          col=colors,zlim=zlim,
          xlab="Time",ylab="Frequency",main=paste("True",titles[r]),
          useRaster=TRUE)
    # abline(v=true_xi[2:(length(true_xi)-1)],lty=2)
    par(mar=c(4,4,3,1))
    image(x=time,y=omega,z=t(estimated_values[[r]]),
      col=colors,zlim=zlim,
      xlab="Time",ylab="Frequency",main=paste("Estimated", titles[r]),
      useRaster = TRUE)

    par(mar = c(4, 0, 3, 4))
    image(x=c(0,1),
      y = seq(zlim[1], zlim[2], length.out = length(colors) + 1),
      z = matrix(1:length(colors), 1, length(colors)),
      col = colors,
      xaxt = "n",
      yaxt = "n",
      xlab = "",
      ylab = "",
      useRaster = TRUE
    )
    axis(4, las = 1)
  }
}
