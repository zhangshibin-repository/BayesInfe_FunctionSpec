select_p<-function(X,delta,basis){
  N<-ncol(X)
  nharm<-min(basis$nbasis,N)
  result<-fpca(X,nharm,basis)
  eigenvalues<-pmax(result$eigenvalues,0)
  cumulative<-cumsum(eigenvalues)/sum(eigenvalues)
  p<-which(cumulative>1-delta)[1]
}


fpca<-function(X,p,basis){
  T<-nrow(X)
  u<-seq(0,1,length.out=T)

  fd<-Data2fd(argvals=u,y=X,basisobj=basis)
  result<-pca.fd(fdobj=fd,nharm=p,centerfns=TRUE)
  scores<-as.matrix(result$scores[,1:p,drop=FALSE])
  eigenfunctions<-matrix(eval.fd(u,result$harmonics[1:p]),nrow=T,ncol=p)

  for(j in 1:p){
    if(eigenfunctions[which.max(abs(eigenfunctions[,j])),j]<0){
      eigenfunctions[,j]<--eigenfunctions[,j]
      scores[,j]<--scores[,j]
    }
  }

  list(eigenfunctions=eigenfunctions,
       scores=scores,
       eigenvalues=as.numeric(result$values[1:p])
  )
}

segment_fpca<-function(left,right,control){
  X_segment<-control$X[,(left+1):right,drop=FALSE]
  result<-fpca(X_segment,control$p,control$basis)
  #
  N_l<-nrow(result$scores)
  K<-floor((N_l-1)/2)
  k<-1:K
  omega<-k/N_l      #这里的omega只是这段的oemga, 因此不需要保存, 计算真实谱密度时用的频率是另一套
  y<-mvfft(result$scores)[k+1, ,drop=FALSE]/sqrt(2*pi*N_l)

  list(eigenfunctions=result$eigenfunctions,
       y=y,
       psi=psi_basis(omega,control$J),
       phi=phi_basis(omega,control$J)
  )
}
