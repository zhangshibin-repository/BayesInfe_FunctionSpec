within<-function(state,control){
  if(state$m==1){
    segment<-state$segments[[1]]
    hmc<-hmc_update(segment,segment$fpca,control)
    if(!hmc$success){
      state$segments[[1]]<-gibbs_update(segment,control)
      return(state)
    }
    
    proposed<-segment
    proposed$beta<-hmc$beta
    
    log_ratio<-segment_beta_logposterior(proposed,control)-segment_beta_logposterior(segment,control)+
      hmc$kinetic_current - hmc$kinetic_proposed
    
    decision<-accept_move(log_ratio)
    if(decision$accepted){segment<-proposed}
    state$segments[[1]]<-gibbs_update(segment,control)
    return(state)
  }

  segment_id<-sample(1:(state$m-1),1)
  
  left_boundary <-state$xi[segment_id]
  current_point <-state$xi[segment_id+1]
  right_boundary<-state$xi[segment_id+2]
  
  global_lower<-left_boundary+control$t_min
  global_upper<-right_boundary-control$t_min
  global_support<-global_lower:global_upper
  
  local_lower<-max(global_lower,current_point-control$relocation_radius)
  local_upper<-min(global_upper,current_point+control$relocation_radius)
  local_support<-local_lower:local_upper
  
  if (runif(1)<control$rho){support<-local_support} else {support<-global_support}
  
  point_id<-sample(1:length(support),1)
  proposed_point<-support[point_id]
  
  left <-state$segments[[segment_id]]
  right<-state$segments[[segment_id+1]]
  
  if(proposed_point==current_point){
    left_fpca<-left$fpca
    right_fpca<-right$fpca
  } else {
    left_fpca <-segment_fpca(left_boundary, proposed_point,control)
    right_fpca<-segment_fpca(proposed_point,right_boundary,control)
  }
  
  hmc_left <-hmc_update(left, left_fpca, control)
  hmc_right<-hmc_update(right,right_fpca,control)
  
  if(!hmc_left$success || !hmc_right$success){
    state$segments[[segment_id]]  <-gibbs_update(left, control)
    state$segments[[segment_id+1]]<-gibbs_update(right,control)
    return(state)
  }
  
  proposed_left <-left
  proposed_right<-right
  
  proposed_left$beta <-hmc_left$beta
  proposed_right$beta<-hmc_right$beta
  
  proposed_left$fpca <-left_fpca
  proposed_right$fpca<-right_fpca
  
  proposed_xi<-state$xi
  proposed_xi[segment_id+1]<-proposed_point
  
  reverse_local_lower<-max(global_lower,proposed_point-control$relocation_radius)
  reverse_local_upper<-min(global_upper,proposed_point+control$relocation_radius)
  
  reverse_local_support<-reverse_local_lower:reverse_local_upper
  q_proposed<-(1-control$rho)/length(global_support)+
    control$rho*as.numeric(proposed_point %in% local_support)/length(local_support)
  q_current<-(1-control$rho)/length(global_support)+ 
    control$rho*as.numeric(current_point %in% reverse_local_support)/length(reverse_local_support)
  
  log_ratio<-
    segment_beta_logposterior(proposed_left,control)+segment_beta_logposterior(proposed_right,control)-
    segment_beta_logposterior(left,control)-segment_beta_logposterior(right,control)+
    hmc_left$kinetic_current+hmc_right$kinetic_current -
    hmc_left$kinetic_proposed-hmc_right$kinetic_proposed+
    log_partition_prior(proposed_xi,control$N,control$t_min)-
    log_partition_prior(state$xi,control$N,control$t_min)+
    log(q_current)-log(q_proposed)
  
  decision <- accept_move(log_ratio)

  if(decision$accepted) {
    state$xi<-proposed_xi
    left<-proposed_left
    right<-proposed_right
  }
  
  state$segments[[segment_id]]  <-gibbs_update(left, control)
  state$segments[[segment_id+1]]<-gibbs_update(right,control)
  state
}
